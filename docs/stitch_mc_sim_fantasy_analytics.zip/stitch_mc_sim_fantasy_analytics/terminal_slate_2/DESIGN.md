---
name: Terminal Slate
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e0e2ec'
  on-surface-variant: '#d3c5ac'
  inverse-surface: '#e0e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#9c8f79'
  outline-variant: '#4f4633'
  surface-tint: '#f9bd22'
  primary: '#ffe1a7'
  on-primary: '#402d00'
  primary-container: '#fbbf24'
  on-primary-container: '#6c4f00'
  inverse-primary: '#795900'
  secondary: '#bdc2ff'
  on-secondary: '#131e8c'
  secondary-container: '#2f3aa3'
  on-secondary-container: '#a8afff'
  tertiary: '#78ff96'
  on-tertiary: '#003915'
  tertiary-container: '#4ce378'
  on-tertiary-container: '#006129'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdf9f'
  primary-fixed-dim: '#f9bd22'
  on-primary-fixed: '#261a00'
  on-primary-fixed-variant: '#5c4300'
  secondary-fixed: '#e0e0ff'
  secondary-fixed-dim: '#bdc2ff'
  on-secondary-fixed: '#000767'
  on-secondary-fixed-variant: '#2f3aa3'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#10131a'
  on-background: '#e0e2ec'
  surface-variant: '#32353c'
  canvas-bg: '#0B0E14'
  surface-card: '#10131A'
  surface-elevated: '#191C22'
  surface-overlay: '#1E232E'
  border-subtle: '#232A36'
  border-interactive: '#3E484F'
  status-ready: '#22C55E'
  status-warning: '#F59E0B'
  status-critical: '#EF4444'
  badge-qb: '#38BDF8'
  badge-rb: '#22C55E'
  badge-wr: '#FBBF24'
  badge-te: '#818CF8'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  table-row-height: 1.875rem
  header-height: 2.75rem
  gutter-panel: 0.5rem
  margin-viewport: 1rem
---

## Brand & Style

This design system is engineered for quantitative fantasy football analysts, computational strategists, and high-stakes decision-makers who run thousands of Monte Carlo game iterations. It rejects consumer gamification, skeuomorphic noise, and gratuitous motion in favor of high-throughput data density, absolute mathematical legibility, and tactical mission-control precision.

The aesthetic fuses **Modern Technical Terminal Architecture** with **High-Performance Financial Engineering**:
- **Pure Dark Slate Immersion:** Deep slate foundations eliminate eye strain over lengthy analysis sessions and establish a focused, low-luminance canvas.
- **Instrumental Color Hierarchy:** Non-directional accents guide focus without competing with conventional alpha and liability indicators (green for upside/percentile gains, crimson for injury/negative variance). Topaz Amber anchors distribution shapes, median runs, and primary action triggers, while Indigo Violet designates player positional identity and deep categorical metadata.
- **Micro-Hairline Boundaries:** Information architecture is framed strictly via crisp 1-pixel borders rather than ambient blur or heavy drop shadows, maximizing vertical and horizontal scan velocity.
- **Data-First Proportionality:** Compact row pitches, monospace telemetry blocks, and tabular figures empower the operator to inspect hundreds of simulation iterations, ownership leverage percentages, and ceiling/floor ranges without unnecessary scrolling.

## Colors

The color architecture is built around a non-glare, dark slate base optimized for chart contrast and dense tabular data.

### Structural Foundations & Surfaces
- **Canvas Base (`#0B0E14`):** The lowest layer of the viewport. Serves as the backdrop for all nested grids and analytics panels.
- **Surface / Card (`#10131A`):** The primary container background for telemetry modules, data grids, and histogram viewports.
- **Elevated Canvas (`#191C22`):** Elevated interactive zones, hovered table rows, and secondary filter pill clusters.
- **Overlay Surface (`#1E232E`):** Tooltips, floating distribution inspector cards, flyout menus, and modal dialogs.
- **Hairline Border (`#232A36`):** The primary structural boundary applied at 1px across table rows, column splitters, and panel perimeters.
- **Interactive Border (`#3E484F`):** Hover and focus border states for inputs, sliders, and interactive table cells.

### Accents & Telemetry
- **Primary Accent (`#FBBF24` - Topaz Amber):** Serves as the key focal anchor. Used for P50 median projection curves, 30% alpha fill under probability density functions, primary CTA actions, active navigation states, and high-attention run counters.
- **Secondary Accent (`#818CF8` - Indigo Violet):** Used for categorical structure: positional markers (WR/TE), player initials avatars, subtle section underlines, and secondary model constraint indicators.
- **System Telemetry & Semantics:**
  - **Connected / Engine Ready (`#22C55E`):** Monte Carlo engine active, valid iteration state, alpha upside (P90).
  - **Deficit / Attention (`#F59E0B`):** Convergence warnings, game-time decision tags, unresolved run configurations.
  - **Critical / Liability (`#EF4444`):** Model drift, out/IR injuries, bust probability, negative leverage.

## Typography

The typographic system bifurcates between human-readable administrative headers and rigorous computational figures:

1. **Plus Jakarta Sans** provides a modern, legible sans-serif structure for views, section headers, player names, and informational text.
2. **JetBrains Mono** powers all numerical figures, simulation outputs, latency metrics, percentiles (P10/P50/P90), covariance tables, and data column headers.

### Tabular Formatting Rules
- **Monospace Numeric Alignment:** All statistical outputs, points per dollar, fantasy point projections, standard deviations, and hash signatures must render in `JetBrains Mono` with fixed character widths.
- **Tabular Decimal Anchoring:** Numbers inside tables are right-aligned to maintain consistent vertical decimal tracking across hundreds of continuous rows.
- **Uppercase Column Headers:** Analytical column headers, simulation metadata keys, and axis units use `label-caps` set in full uppercase with `0.06em` letter spacing.
- **Tight Headings:** High-level section headings feature negative tracking (`-0.02em` to `-0.03em`) to prevent visual sprawl across dense multi-column dashboard layouts.

## Layout & Spacing

The layout model is built on an ultra-compact 4px grid rhythm, optimized for maximum vertical and horizontal data capacity on 1440px and ultrawide viewports.

### Multi-Column Analytical Workstation
- **Fixed-Ratio Viewport Model:** Screen space is divided using seamless edge-to-edge docking rather than wide whitespace margins.
- **Layout Partitioning:**
  - **Left Sidebar (280px–320px fixed):** Monte Carlo run parameters, sample size counters, correlation sliders, and lineup constraints.
  - **Center Stage (Fluid flex-grow):** Multi-iteration outcome distribution charts, density plots, and the master player table.
  - **Right Sidebar (340px–380px fixed):** Individual player inspector, range-of-outcomes radar, percentiles breakdown, and exposure allocation.
- **Abutting Panel Interfaces:** Panels share adjacent 1px borders (`#232A36`) rather than floating with whitespace gutters, preserving screen space for data display.

### Responsive Breakpoints
- **Ultrawide & Desktop (>= 1440px):** Full three-column concurrent dashboard with simultaneous histogram curves and 40+ table rows.
- **Standard Desktop (1024px – 1439px):** Left parameter column collapses into an icon-dense flyout toolbar; right inspector drops into a toggleable bottom drawer.
- **Tablet & Compact (< 1024px):** Single-column stacked mode with locked left identification columns and horizontal scrolling data matrices.

## Elevation & Depth

Visual hierarchy uses tonal surface layering and hairline borders instead of diffuse shadows or blur effects, ensuring high-frequency data remains legible without atmospheric interference.

### Surface Hierarchy
- **Level 0 (Canvas):** `#0B0E14` — Deep canvas floor behind charts and master grids.
- **Level 1 (Card & Module):** `#10131A` bounded by a 1px `#232A36` border. Demarcates standard charts, control modules, and summary panels.
- **Level 2 (Hover & Interactive Surfaces):** `#191C22` bounded by a 1px `#3E484F` border. Highlights selected table rows, active input fields, and pill selectors.
- **Level 3 (Overlays & Inspectors):** `#1E232E` with a subtle top hairline highlight `inset 0 1px 0 0 rgba(251, 191, 36, 0.15)` and border `#232A36`. Used for hovering quantile inspectors, tooltips, and modal configurations.

### Focus and Selection States
- Selected records or simulation iterations apply an active border in `#FBBF24` paired with an inner fill of `rgba(251, 191, 36, 0.06)`.
- Positional card active states apply an active border in `#818CF8` with an inner fill of `rgba(129, 140, 248, 0.08)`.

## Shapes

The design system uses a **Soft Precision (Level 1)** geometry with tight 4px to 6px corner radii. This preserves the feel of a terminal console while softening hard corners to maintain readable groupings across high-density elements.

- **Micro Radii (2px):** Position indicator tags (QB, RB, WR, TE), correlation tags, and small table status pills.
- **Core Component Radii (4px / 0.25rem):** Action buttons, numeric inputs, dropdown selectors, and telemetry chips.
- **Container Radii (6px / 0.375rem):** Outer corners of analytic panels, distribution chart cards, and modal dialogs.
- **Table Cells & Interior Dividers (0px):** Square interior cells prevent broken visual lines along structural borders.

## Components

### Buttons & Trigger Actions
- **Primary Execution Button:** Background `#FBBF24`, text `#0B0E14` (Plus Jakarta Sans 13px, weight 700). Hover `#F59E0B`. Active `#D97706`. Height 30px, padding 6px 14px, radius 4px.
- **Secondary Action Button:** Background `#10131A`, border 1px `#232A36`, text `#E1E2EB`. Hover border `#818CF8`, text `#818CF8`. Height 30px, padding 6px 12px, radius 4px.
- **Icon / Telemetry Action:** Background transparent, border 1px transparent, text `#BDC8D1`. Hover background `#191C22`, hover border `#232A36`, hover text `#FBBF24`. Size 28px x 28px.

### Inputs & Micro Sliders
- **Monospace Numeric Input:** Background `#0B0E14`, border 1px `#232A36`, text `#F1F5F9`, font JetBrains Mono 13px. Height 28px. Focus: border 1px `#FBBF24` with zero drop-shadow.
- **Parameter & Correlation Slider:** Rail height 3px in `#232A36`. Active track filled with `#FBBF24`. Drag handle: 10px x 10px square with a 2px radius, fill `#E1E2EB`, border 1px `#0B0E14`.

### Data Grid & Tabular Matrix
- **Row Pitch:** Fixed 30px (1.875rem) vertical row height.
- **Header Row:** Background `#10131A`, bottom border 1px `#232A36`. Font: JetBrains Mono 10px uppercase `label-caps` in `#BDC8D1`. Right-aligned for numeric statistics, left-aligned for player names.
- **Row Cells:** Bottom border 1px `#191C22`, text `#E1E2EB`, font JetBrains Mono 13px. Alternate rows feature an optional `#0E1118` surface fill.
- **Hover Row Highlight:** Full row background set to `rgba(251, 191, 36, 0.04)`.

### Chips & Positional Badges
- **Position Badges:** JetBrains Mono 10px, weight 700, padding 1px 5px, radius 2px.
  - QB: Background `rgba(56, 189, 248, 0.12)`, text `#38BDF8`, border 1px `rgba(56, 189, 248, 0.25)`.
  - RB: Background `rgba(34, 197, 94, 0.12)`, text `#22C55E`, border 1px `rgba(34, 197, 94, 0.25)`.
  - WR: Background `rgba(251, 191, 36, 0.12)`, text `#FBBF24`, border 1px `rgba(251, 191, 36, 0.25)`.
  - TE: Background `rgba(129, 140, 248, 0.12)`, text `#818CF8`, border 1px `rgba(129, 140, 248, 0.25)`.
- **Telemetry Indicators:** 6px circular dot. Engine Ready: `#22C55E`. Warning / Recalculating: `#F59E0B`. Critical / Failure: `#EF4444`.

### Checkboxes & Switches
- **Terminal Checkbox:** 14px x 14px square, radius 2px. Unchecked: background `#0B0E14`, border 1px `#232A36`. Checked: background `#FBBF24`, border `#FBBF24`, checkmark icon `#0B0E14`.
- **Toggle Switch:** Width 26px, height 14px, background `#1E232E`, radius 7px. Active state: track `#818CF8`. Thumb: 10px circle in `#E1E2EB`.

### Cards & Panels
- **Panel Shell:** Background `#10131A`, border 1px `#232A36`, radius 6px.
- **Panel Header:** Height 34px, padding 0 12px, border-bottom 1px `#232A36`. Displays uppercase panel titles with right-aligned action icons or latency counters.
- **Data Body:** Padding 8px 12px. Zero padding on flush child data grids.