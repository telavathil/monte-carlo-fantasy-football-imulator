---
name: Terminal Slate
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2eb'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#e1e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#93ccff'
  on-secondary: '#003351'
  secondary-container: '#3198dc'
  on-secondary-container: '#002c47'
  tertiary: '#ffc174'
  on-tertiary: '#472a00'
  tertiary-container: '#f59e0b'
  on-tertiary-container: '#613b00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#10131a'
  on-background: '#e1e2eb'
  surface-variant: '#32353c'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  numeric-data-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  numeric-data-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  numeric-data-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  gutter-data: 0.5rem
  panel-padding: 0.75rem 1rem
  table-row-height: 1.875rem
---

## Brand & Style

This design system is engineered for elite quantitative workflows, precision simulation tooling, and high-frequency analytical consumption. Designed specifically for an expert single-user persona, the visual identity rejects consumer gamification, decorative clutter, and exaggerated transitions in favor of deep structural clarity, extreme spatial efficiency, and computational authority.

The aesthetic fuses **Precision Engineering Minimalism** with **Tactical Mission-Control Telemetry**:
- **Pure Dark Slate Immersion:** Dominant deep slate foundations eliminate visual fatigue during sustained quantitative analysis.
- **Instrumental Restraint:** Non-semantic primary accents provide contrast without interfering with conventional financial or performance indicators (green for positive variance, red for negative variance, amber for unresolved states).
- **Hairline Structural Orthogonality:** Clean 1px boundary lines demarcate information spaces instead of heavy drop shadows or diffuse blurs.
- **Uncompromised Density:** Tight padding, monospaced tabular figures, and minimal vertical rhythm empower the user to view dozens of simulation iterations and player percentiles simultaneously on a single desktop canvas.

## Colors

The color architecture is built around a non-directional, high-contrast core. Because performance modeling uses green and red to communicate alpha, upside, downside, and injury liabilities, the structural and brand accents intentionally stay clear of these hues.

### Foundation & Surfaces
- **App Background (`#0B0E14`):** Near-black slate base canvas. Absorb visual weight, anchors high-contrast tabular values.
- **Elevated Canvas / Card (`#151A23`):** First-tier elevated module surface. Delivers distinct separation from `#0B0E14` without raising visual luminance.
- **Elevated Modal / Dropdown (`#1C2330`):** Second-tier floating layer for popovers, cell inspector tooltips, and flyout selectors.
- **Border Subtle / Hairline (`#232A36`):** The structural workhorse line color. Applied at exactly 1px to table cells, card dividers, and header splitters.
- **Border Interactive (`#333E50`):** Hover and keyboard focus indicator for input fields and toggles.

### Core Accents
- **Primary Accent (`#38BDF8` - Electric Cyan):** Core focal point for interactive states, key callouts, selected tabs, and Monte Carlo trendline paths. Produces an exceptional >8:1 contrast ratio against the slate foundation and carries zero semantic confusion with positive/negative values.
- **Secondary Accent (`#0284C7` - Deep Cerulean):** Active selection backgrounds (at 15–20% opacity), muted focus rings, and secondary range-fill indicators.

### Semantics & Status
- **Success / Connected (`#10B981`):** Webhook connections, live data socket sync, positive point-spread variance, upside outcome percentiles (90th percentile).
- **Warning / Unresolved (`#F59E0B`):** Monte Carlo convergence warnings, ambiguous player statuses (questionable/game-time decisions), unresolved parameter inputs.
- **Critical / Downside (`#EF4444`):** Model drift, out/IR injury status, negative leverage tiers, bust rate probabilities.

### Typography Scales
- **Text Crisp Primary (`#F1F5F9`):** Primary metric outputs, simulation player names, tabular values.
- **Text Muted / Secondary (`#7A8699`):** Column descriptors, stat category tags, axis labels, disabled state values.
- **Text Ghost / Hairline (`#475569`):** Trailing zeros, placeholder prompts, table sorting inactive indicators.

## Typography

The type scale combines **Plus Jakarta Sans** for compact, authoritative section anchors with **Inter** for dense analytical workhorses.

### Tabular Formatting Rules
- **Strict Tabular Alignment:** All numeric data—including projections, standard deviations, ceiling/floor projections, ownership percentages, and currency salaries—must use `font-variant-numeric: tabular-nums` (`tnum`).
- **Headings Tracking:** Headings use tighter tracking (`-0.02em` to `-0.03em`) to preserve vertical and horizontal scan velocity.
- **Label Capitalization:** Analytical table headers, quadrant legends, and run parameters use `label-caps` rendered in uppercase with expanded tracking (`0.06em`) in secondary text color (`#7A8699`).
- **Numerical Alignment:** Quantitative figures in tables must always align to the right, aligning decimals strictly with the header label. Text columns (e.g., Player Name, Team, Position) align to the left.

## Layout & Spacing

The architecture operates on an ultra-compact 4px modular base unit, engineered specifically for a primary target resolution of 1440px+ on desktop monitors, with responsive adaptations stretching to full-width ultrawide canvases.

### Layout Philosophy
- **Fixed-Ratio Modular Grid:** The master canvas relies on a full-width viewport arrangement with minimal outer margins (16px) to maximize the analytical payload.
- **Split Telemetry Workspaces:** Standard desktop views partition into:
  - Left: Global parameter, iteration count, correlation matrix, and constraint adjustments (280px–320px fixed).
  - Center: Master tabular simulation matrix / distribution histograms (flex fluid).
  - Right: Player-specific outcome percentiles, range-of-outcomes radar, and injury sensitivity cards (340px–380px fixed).
- **Hairline Structural Boundaries:** Rather than using whitespace padding to differentiate panels, adjacent panels touch directly along 1px `#232A36` borders. This conserves vertical screen space, providing immediate structural boundaries for 40+ table rows without scrolling.

### Breakpoint Adaptation
- **Desktop (>= 1440px):** Primary target. Three-column persistent telemetry view with full data tables visible concurrently with distribution curves.
- **Compact Desktop / Laptop (1024px – 1439px):** Collapsible left parameter sidebar into an icon-dense drawer; right panel tabs underneath table analysis.
- **Tablet (< 1024px):** Single-column stacked mode with horizontal scrolling data tables and sticky player identification columns.

## Elevation & Depth

This design system avoids traditional dropped shadows, ambient lighting cones, and multi-colored blurred depths. In a computational analytics environment, ambient shadows add visual noise around high-frequency grid intersections.

Visual hierarchy relies on **Tonal Layering** and **Hairline Outlines**:

- **Ground Zero (Canvas):** `#0B0E14` (Deep Slate) is the foundational layer. Grid charts and table backgrounds draw contrast straight from this canvas.
- **Tier 1 (Panels & Cards):** `#151A23` elevated background bounded by a solid 1px `#232A36` border. This distinguishes data modules, configuration blocks, and summary headers.
- **Tier 2 (Sticky Headers & Tooltips):** `#1C2330` elevated surface with a 1px `#333E50` outline. Used for pinned sticky table headers, hovering quantile inspectors, and context menus.
- **Tier 3 (Modals & Parameter Overlays):** Background `#151A23` supported by a low-opacity inset accent stroke: `inset 0 1px 0 0 rgba(56, 189, 248, 0.2)` combined with a sharp hairline border `#38BDF8`.
- **Active Focus & Selection:** Selection states use a 1px border of `#38BDF8` accompanied by a localized inner fill of `rgba(56, 189, 248, 0.08)`.

## Shapes

The shape system adopts a **Soft Precision (Level 1)** framework:

- **Base Radius (0.25rem / 4px):** Standard UI modules including form controls, dropdown triggers, parameter pills, and secondary buttons. This subtle curvature maintains structural sharpness while softening raw brutalist corners.
- **Container Radius (0.375rem / 6px to 0.5rem / 8px):** Outer borders of dashboard panels, distribution chart containers, and modal dialogs.
- **Table Cells & Grid Items (0px):** Strictly square interior cells to avoid broken visual lines across vertical and horizontal grid borders.
- **Badges & Position Tags (2px):** Minimal corner breaks on position labels (QB, RB, WR, TE) for micro-scale legibility.

## Components

### Buttons
- **Primary Button:** Background `#38BDF8`, text `#0B0E14` (Inter 13px, weight 600). Hover `#7DD3FC`. Active `#0284C7`. Radius 4px. Padding: 6px 12px.
- **Secondary Button:** Background `#151A23`, border 1px `#232A36`, text `#F1F5F9`. Hover border `#38BDF8`, text `#38BDF8`. Padding: 6px 12px.
- **Ghost / Tool Action:** Background transparent, text `#7A8699`. Hover text `#F1F5F9`, hover background `rgba(255, 255, 255, 0.04)`. Radius 4px.

### Inputs & Parameter Sliders
- **Text / Numeric Inputs:** Background `#0B0E14`, border 1px `#232A36`, text `#F1F5F9`, font-variant-numeric `tabular-nums`. Height 28px for compact density. Focus ring: 1px `#38BDF8` with zero outer blur.
- **Range / Correlation Sliders:** Track height 4px, track background `#232A36`. Filled portion `#38BDF8`. Thumb: 12px square or circular target `#F1F5F9` with hover ring `rgba(56, 189, 248, 0.3)`.

### Data Grid & Simulation Tables
- **Row Height:** Compact 30px (1.875rem) vertical row pitch.
- **Header Cells:** Background `#151A23`, border-bottom 1px `#232A36`, font: Inter 10px uppercase `label-caps`, color `#7A8699`.
- **Data Cells:** Border-bottom 1px `#1A212C`, text `#F1F5F9`, font: Inter 13px tabular-nums.
- **Zebra Striping:** Optional alternates using `#11161F` on even rows for tables exceeding 15 columns.
- **Hover Row Highlight:** Row background `rgba(56, 189, 248, 0.04)` across all frozen and fluid cells.

### Position Badges & Status Chips
- **Position Badges:** 10px font, weight 700, padding 1px 4px, radius 2px.
  - QB: Background `rgba(56, 189, 248, 0.15)`, text `#38BDF8`.
  - RB: Background `rgba(16, 185, 129, 0.15)`, text `#10B981`.
  - WR: Background `rgba(245, 158, 11, 0.15)`, text `#F59E0B`.
  - TE: Background `rgba(168, 85, 247, 0.15)`, text `#C084FC`.
- **Status Indicators:** Micro 6px dot. Success `#10B981`, Amber Unresolved `#F59E0B`, Danger `#EF4444`.

### Cards & Telemetry Panels
- **Panel Base:** Background `#151A23`, border 1px `#232A36`, radius 6px.
- **Panel Header:** Border-bottom 1px `#232A36`, padding: 8px 12px. Flex layout with title on the left and micro control actions on the right.
- **Data Densified Body:** Padding 8px 12px. No nested padding buffers between child tables and card borders.

### Checkboxes & Toggle Switches
- **Checkboxes:** 14px x 14px, background `#0B0E14`, border 1px `#232A36`, radius 2px. Checked: background `#38BDF8`, border-color `#38BDF8`, icon `#0B0E14`.
- **Switches:** Width 28px, height 16px, background `#232A36`, radius 8px. Checked track `#0284C7`. Thumb 12px `#F1F5F9`.